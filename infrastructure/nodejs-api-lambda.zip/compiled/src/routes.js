"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const multer_1 = require("./multer");
const main_1 = require("./main");
const router = express_1.default.Router();
console.log('Setting up routes...'); // Add debugging
router.get('/test', (req, res) => {
    console.log('Test route hit!'); // Add debugging
    res.json({ message: 'Router is working!' });
});
// Existing file upload
router.post('/upload', multer_1.upload.single('file'), main_1.uploadFileHandler);
// NEW: Translation routes
router.post('/translate/text', main_1.translateTextHandler);
router.post('/translate/file', multer_1.upload.single('file'), main_1.translateFileHandler);
router.get('/translate/status/:requestId', main_1.getTranslationStatusHandler);
console.log('Routes setup complete'); // Add debugging
exports.default = router;
//# sourceMappingURL=routes.js.map