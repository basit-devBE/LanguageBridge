// AWS Lambda handler that adapts your Node.js Express API
const path = require('path');
const fs = require('fs');

// Import your compiled handlers
const { translateTextHandler, translateFileHandler, getTranslationStatusHandler } = require('./compiled/src/main');

// Mock Express Request/Response objects for Lambda
class MockRequest {
    constructor(event) {
        this.body = event.body ? JSON.parse(event.body) : {};
        this.params = event.pathParameters || {};
        this.query = event.queryStringParameters || {};
        this.headers = event.headers || {};
        this.method = event.httpMethod;
        this.path = event.path;
        
        // For file upload simulation
        this.file = null;
    }
}

class MockResponse {
    constructor() {
        this.statusCode = 200;
        this.responseBody = {};
        this.headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
        };
    }

    status(code) {
        this.statusCode = code;
        return this;
    }

    json(body) {
        this.responseBody = body;
        return this;
    }

    send(body) {
        this.responseBody = body;
        return this;
    }

    toAPIGatewayResponse() {
        return {
            statusCode: this.statusCode,
            headers: this.headers,
            body: JSON.stringify(this.responseBody)
        };
    }
}

// File upload handler for Lambda
function handleFileUpload(req) {
    if (req.body.fileContent && req.body.fileName) {
        const tempDir = '/tmp';
        const filename = `upload_${Date.now()}.json`;
        const filePath = path.join(tempDir, filename);
        
        // Write file content to /tmp
        fs.writeFileSync(filePath, req.body.fileContent);
        
        req.file = {
            filename: filename,
            originalname: req.body.fileName || 'upload.json',
            mimetype: 'application/json',
            path: filePath
        };
        
        // Override the uploads directory for Lambda
        process.cwd = () => tempDir;
    }
}

// Main Lambda handler
exports.handler = async (event, context) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    try {
        const req = new MockRequest(event);
        const res = new MockResponse();
        
        const requestPath = event.path;
        const method = event.httpMethod;
        
        console.log(`Processing ${method} ${requestPath}`);
        
        // Route to appropriate handler
        if (requestPath === '/translate/text' && method === 'POST') {
            await translateTextHandler(req, res);
        } else if (requestPath === '/translate/file' && method === 'POST') {
            handleFileUpload(req);
            await translateFileHandler(req, res);
        } else if (requestPath.startsWith('/translate/status/') && method === 'GET') {
            await getTranslationStatusHandler(req, res);
        } else {
            res.status(404).json({ error: 'Not Found', path: requestPath, method: method });
        }
        
        return res.toAPIGatewayResponse();
        
    } catch (error) {
        console.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Internal Server Error',
                message: error.message,
                stack: error.stack
            })
        };
    }
};
